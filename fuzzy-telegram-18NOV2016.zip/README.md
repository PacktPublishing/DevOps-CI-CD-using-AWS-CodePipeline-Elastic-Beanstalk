# Fuzzy Telegram
*A simple vanilla PHP web application displaying random quote of the day.*

